/*
* �����ߣ���¶¶
* ����ʱ�䣺2022.2.3
* ������FlexibleFloat�࣬��������FlexibleFloat
* FlexibleColorModifierUnit�࣬��������FlexibleColorModifierUnit
*/

#pragma once
#include <iostream>
#include <string>
#include "type.hpp"
using std::cout;
using std::endl;
using std::string;
using std::to_string;

class FlexibleFloat {
public:
	FlexibleFloat():_Dat("") {}
	~FlexibleFloat(){}
public:
	void startAdd(AnimatedFloat af) {
		_Dat += "new FlexibleFloat("
			"new List<AnimatedFloat>(){"
			"\r\nnew AnimatedFloat("
			+ to_string(af.startValue)
			+ "f, "
			+ to_string(af.endValue)
			+ "f, "
			+ to_string(af.startTime)
			+ "f, "
			+ to_string(af.endTime)
			+ "f, "
			+ af.animationCurve
			+ ")";
		_Dat += _CRLF;
	}

	void add(AnimatedFloat af) {
		_Dat += ",new AnimatedFloat("
			+ to_string(af.startValue)
			+ "f, "
			+ to_string(af.endValue)
			+ "f, "
			+ to_string(af.startTime)
			+ "f, "
			+ to_string(af.endTime)
			+ "f, "
			+ af.animationCurve
			+ ")";
		_Dat += _CRLF;
	}

	void endAdd() {
		_Dat += "})";
		_Dat += _CRLF;
	}

	string data()const {
		return _Dat;
	}
private:
	string _Dat;
};

struct FlexibleColorModifierUnit
{
	FlexibleFloat start;
	FlexibleFloat end;
	FlexibleFloat colorR;
	FlexibleFloat colorG;
	FlexibleFloat colorB;
	FlexibleFloat colorA;
	FlexibleFloat centerStart;
	FlexibleFloat centerEnd;
	FlexibleFloat blend;
	FlexibleFloat position;
};
